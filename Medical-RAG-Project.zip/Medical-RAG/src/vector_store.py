import os, json, faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from .config import Config

class VectorStoreManager:
    def __init__(self):
        self.model = SentenceTransformer(Config.EMBEDDING_MODEL_NAME, device=Config.DEVICE)
        self.index, self.records = None, []

    def create_embeddings(self, chunks):
        texts = [chunk["text"] for chunk in chunks]
        return self.model.encode(texts, prompt_name="Retrieval-document", normalize_embeddings=True)

    def build_index(self, chunks, embeddings):
        self.index = faiss.IndexFlatIP(Config.EMBEDDING_DIM)
        self.index.add(embeddings.astype("float32"))
        self.records = [{"chunk_id": i, "text": c["text"], "metadata": c["metadata"]} for i, c in enumerate(chunks)]
        self.save()

    def save(self):
        os.makedirs(Config.RAG_DATA_DIR, exist_ok=True)
        faiss.write_index(self.index, Config.INDEX_PATH)
        with open(Config.CHUNKS_PATH, "w", encoding="utf-8") as f:
            json.dump(self.records, f, ensure_ascii=False, indent=2)

    def load(self):
        if os.path.exists(Config.INDEX_PATH):
            self.index = faiss.read_index(Config.INDEX_PATH)
            with open(Config.CHUNKS_PATH, "r", encoding="utf-8") as f: self.records = json.load(f)
            return True
        return False

    def search(self, query, top_k=Config.TOP_K):
        q_emb = self.model.encode(query, prompt_name="Retrieval-query", normalize_embeddings=True).astype("float32").reshape(1, -1)
        scores, indices = self.index.search(q_emb, top_k)
        results = []
        for s, i in zip(scores[0], indices[0]):
            if i != -1 and s >= Config.MIN_SCORE:
                res = self.records[int(i)]
                res["score"] = float(s)
                results.append(res)
        return results
